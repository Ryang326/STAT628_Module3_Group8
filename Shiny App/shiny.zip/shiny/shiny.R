library(shiny)
library(ggplot2)
library(fmsb)
library(shinythemes)

#read data
business_data = read.csv('shinydata.csv')
business_data$business_id = as.character(business_data$business_id)
business_data$suggestions = as.character(business_data$suggestions)
business_data$reasons = as.character(business_data$reasons)

bus = business_data

#ui
ui <- navbarPage(strong('Module3:Yelp Data Project'),inverse = T,collapsible = T,theme = shinytheme("cerulean"),
           tabPanel("Group 8",
                    h1(span("Data analysis for pizza chain brand : Pizza Hut ", style = "font-weight: 200"), 
                       style = "font-family: 'Source Sans Pro'; text-align: center;padding: 15px"),
                    fluidPage(
                                    tabsetPanel(
  
                                      
                                      tabPanel(
                                               "Guide",h1(" Insructions for this app"),plotOutput('PizzaHut', width = "80%", height = 220),
                                               h4("This application is designed to provide information and feasible data-driven measures to Pizza Hut, one of the top ten pizza chain brands in the United States. The main functions are as follows:"),
                                               p("General Suggestions: This part is some suggestions for the entire Pizza Hut brand. Our suggestions mainly focus on three aspects, namely service, distribution, and food."),
                                               p("Branch restaurant overview: In this section, you can select a branch of Pizza Hut to view its operating status and the distribution of restaurant reviews."),
                                               p("Branch restaurant suggestions: In this section, you can choose a branch of Pizza Hut to view detailed and feasible suggestions for it.")
                                               #p("End point")
                                               ),
                                      
                                      
                                      
                                      
                                      tabPanel("Gerneral Suggestions",
                                               h1("General Action Plan for Service"),
                                               
                                               h3("Make the Restaurants Kids Friendly"),
                                               p("The average rating of kid-friendly restaurants is about 0.25 higher than that of unfriendly restaurants."),
                                               p("Increase the number of children's seats in the store; like other fast food chains, such as McDonald's, set up a children's play area; enrich the types of children's packages; Set up family toilets."),
                                               
                                               
                                               
                                               h3("Make the Restaurants Groups Friendly"),
                                               p("Those restaurants that are friendly to multi-person dining have an average rating of 0.26 higher than those that are not friendly."),
                                               p("Increase the number of large tables in the store; launch a set menu for multiple adults, not just family meals."),
                                               
                                               h3("Train Managers and Staffs More Friendly"),
                                               p("The average ratings of restaurants with customer-friendly managers are about 1.63 higher than those without."),
                                               p("Strengthen the training of restaurant managers and employees; organize branch selection activities with the best service attitude and provide rewards to motivate employees to be more friendly."),
                                               
                                               h1("General Action Plan for Delivery"),
                                               h3("Make Delivery Faster and On-time"),
                                               p("We found a large number of consumer reviews complaining about delivery, and the average rating of these consumers for restaurants is 1.75."),
                                               p("Cooperate with better food delivery platforms; establish your own delivery team in big cities with a lot of orders."),
                                               
                                               h1("General Action Plan for Food"),
                                               h3("Keep the Food Warm for Eating"),
                                               p("We found a large number of consumer reviews complaining about the food being cold, and the average rating of these consumers on the restaurant is 1.83."),
                                               p("Use an incubator during delivery.")
                                               
                                               #p("End point")
                                               ),
                                      
                                      
                                      
                                      
                                      
                                      tabPanel("Branch restaurant overview",
                                               sidebarLayout(position = "left",
                                                             sidebarPanel(
                                                               p("Please select the branch restaurant you want to view:"),
                                                               selectInput("bus_id1", "Business ID:",choices = c(as.character(unique(bus$business_id))))
                                                              
                                                             ),
                                                             mainPanel( h2("Branch Retaurant Information"),
                                                                        textOutput('shop_star'),
                                                                        textOutput('address'),
                                                                        textOutput('city'),
                                                                        h2("Scores in different dimensions"),textOutput('scores'),
                                                                        plotOutput('specific_overview_scores', width = "80%", height = 400),
                                                                        h2("Customers' feedback"),textOutput('reviews'),
                                                                        plotOutput('specific_overview_reviews', width = "80%", height = 300),
                                                                        #p("End point.")
                                                             ))
                                      ),
                                      
                                      
                                      
                                      
                                      
                                      tabPanel("Branch restaurant suggestions",
                                               sidebarLayout(position = "left",
                                                             sidebarPanel(
                                                               p("Please select the branch restaurant you want to view:"),
                                                               selectInput("bus_id2", "Business ID:",choices = c(as.character(unique(bus$business_id))))
                                                              
                                                             ),
                                                             mainPanel(h2("Specific Suggestions"),
                                                                       textOutput('spec_suggestions'),
                                                                       tags$style(type="text/css", "#spec_suggestions {white-space: pre-wrap;}"),
                                                                       h2("Why we give these suggestions"),
                                                                       textOutput('spec_suggestions_reasons'),
                                                                       tags$style(type="text/css", "#spec_suggestions_reasons {white-space: pre-wrap;}")
                                                                       #p("End Point")
                                                                       )
                                               )),
                                      
                                      tabPanel("Contact us",
                                               h2("If you have any question, please contact us:"),
                                               p("Haoyue Shi, hshi87@wisc.edu"),
                                               p("Shengwen Yang, syang382@wisc.edu"),
                                               p("Yuyang He, he324@wisc.edu"))
                                               )
                                    
                                  )
                    ))





#server
server <- shinyServer(function(input, output) {
  #data preparation 
  
  # Guide
  output$PizzaHut <- renderImage({
    filename <- normalizePath(file.path('PizzaHut.png'))
    list(src = filename,         
         width = 300,
         height = 200)
  }, deleteFile = FALSE)
  
  # General Suggestions
  # Specific branch overview
  
  output$scores <- renderText(
    paste("The performance of this restaurant in five important dimensions is shown below")
  )
  
  output$reviews <- renderText(
    paste("The distribution of consumer reviews is shown in the figure below")
  )
  
  output$shop_star <- renderText({
    specific_id = input$bus_id1
    specific_bus = bus[bus$business_id == specific_id,]
    paste("Shop Ratings : ",specific_bus$shop_star)
  })
  
  output$address <- renderText({
    specific_id = input$bus_id1
    specific_bus = bus[bus$business_id == specific_id,]
    paste("Shop address : ",specific_bus$address)
  })
  
  output$city <- renderText({
    specific_id = input$bus_id1
    specific_bus = bus[bus$business_id == specific_id,]
    paste("City : ",specific_bus$city)
  })
  
  
  
  output$specific_overview_scores <- renderPlot({
    branch_mean = colMeans(bus[, c('is_good_for_kids','is_good_for_groups','delivery','service','food')])
    specific_id = input$bus_id1
    specific_bus = bus[bus$business_id == specific_id,]
    specific_bus = specific_bus[,c('is_good_for_kids','is_good_for_groups','delivery','service','food')]
    data = rbind(specific_bus,branch_mean)
    
    max_min <- data.frame(
      delivery = c(1, 0),food = c(1, 0), service = c(1, 0),
      is_good_for_kids = c(1, 0), is_good_for_groups = c(1, 0)
    );
    rownames(max_min) <- c("Max", "Min")
    # Bind the variable ranges to the data
    data <- rbind(max_min, data)
    radarchart( data, #maxmin = FALSE,
                pcol = c("#00AFBB","#E7B800"),
                pfcol =  c(scales::alpha("#00AFBB", 0.5),scales::alpha("#E7B800", 0.5)),
                plty = "solid",
                cglty = "solid",
                cglcol = "black",
                cglwd =0.5,
                vlcex=1
    )
    legend(
      x = "bottom", legend = c("specific restaurant","average level"), horiz = TRUE,
      bty = "n", pch = 20 , col = c("#00AFBB", "#E7B800"),
      text.col = "black", cex = 1, pt.cex = 1.5
    )
 
  })
  
  output$specific_overview_reviews <- renderPlot({
    specific_id = input$bus_id1
    review_data = bus[bus$business_id == specific_id,]
    review_cnt = matrix(data =review_data[, c('user1_cnt','user2_cnt','user3_cnt','user4_cnt','user5_cnt')],ncol = 5)
    barplot(height = review_cnt, 
            names.arg = c('1','2','3','4','5'),
            col = 'orange',  
            border = "black",
            xlab = 'Rating Star Level',  
            ylab = 'Review Count',
            main = 'Customers\' Ratings'
    )
    
    
    
})
  # Specific branch suggestions
  output$spec_suggestions <- renderText({
    specific_id = input$bus_id2
    suggestion_data = bus[bus$business_id == specific_id,]
    suggestion_data = suggestion_data[,"suggestions"]
    tem_split_str = unlist(strsplit(suggestion_data,split = "[.]"))
    length = length(tem_split_str)
    paste(tem_split_str[1:length],collapse = ".\n")
    
  
    
  })
  
  output$spec_suggestions_reasons <- renderText({
    specific_id = input$bus_id2
    suggestion_data = bus[bus$business_id == specific_id,]
    suggestion_data = suggestion_data[,"reasons"]
    tem_split_str = unlist(strsplit(suggestion_data,split = "[;]"))
    length = length(tem_split_str)
    paste(tem_split_str[1:length],collapse = ".\n")
    
    
  })
  
  output$ranking <- renderPlot({
    if (input$state == 'All'){
      oout <- bus
      ch01 <- ggplot(oout, aes(stars)) +
        geom_histogram(bins = 10,color='darkblue',fill='lightblue')+
        theme_bw()+
        theme(
          axis.text = element_text(face="plain",size=15),      
          axis.title = element_text(face = "plain",size=15),     
          legend.title = element_blank(),                     
          panel.border=element_rect(fill='transparent',color='transparent'),
          axis.line = element_line(color = "black"),            
          legend.text =element_text(size=15),                  
          title = element_text(size = 18),
          panel.grid = element_blank()
        )+
        labs(x = "Stars", y = "Count")
      ch02 <- ggplot(oout, aes(review_count)) +
        geom_histogram(bins = 20,color='darkblue',fill='lightblue')+
        theme_bw()+
        theme(
          axis.text = element_text(face="plain",size=15),     
          axis.title = element_text(face = "plain",size=15),    
          legend.title = element_blank(),                      
          panel.border=element_rect(fill='transparent',         
                                    color='transparent'),
          axis.line = element_line(color = "black"),           
          legend.text =element_text(size=15),                   
          panel.grid = element_blank()#去除背景的分割线
        )+
        labs(x = "Number of Reviews", y = "Count")
      multiplot(ch01,ch02, cols=2)
    }
    else if (input$state != 'All' & input$city == 'All'){
      oout <- bus[bus$state == input$state, ]
      ch11 <- ggplot(oout, aes(stars)) +
        geom_histogram(bins = 10,color='darkblue',fill='lightblue')+
        theme_bw()+
        theme(
          axis.text = element_text(face="plain",size=15),      
          axis.title = element_text(face = "plain",size=15),     
          legend.title = element_blank(),                     
          panel.border=element_rect(fill='transparent',color='transparent'),
          axis.line = element_line(color = "black"),            
          legend.text =element_text(size=15),                  
          title = element_text(size = 18),
          panel.grid = element_blank()
        )+
        labs(x = "Stars", y = "Count")
      ch12 <- ggplot(oout, aes(review_count)) +
        geom_histogram(bins = 20,color='darkblue',fill='lightblue')+
        theme_bw()+
        theme(
          axis.text = element_text(face="plain",size=15),     
          axis.title = element_text(face = "plain",size=15),    
          legend.title = element_blank(),                      
          panel.border=element_rect(fill='transparent',         
                                    color='transparent'),
          axis.line = element_line(color = "black"),           
          legend.text =element_text(size=15),                   
          panel.grid = element_blank()#去除背景的分割线
        )+
        labs(x = "Number of Reviews", y = "Count")
      multiplot(ch11,ch12, cols=2)
    }
    
    else if (input$state != 'All' & input$city != 'All' & input$name == 'All') {
      ppp <- bus[(bus$state == input$state) & (bus$city == input$city),]$business_id
      oout <- bus[bus$business_id %in% ppp, ]
      ch21 <- ggplot(oout, aes(stars)) +
        geom_histogram(bins = 10,color='darkblue',fill='lightblue')+
        theme_bw()+
        theme(
          axis.text = element_text(face="plain",size=15),      
          axis.title = element_text(face = "plain",size=15),     
          legend.title = element_blank(),                     
          panel.border=element_rect(fill='transparent',color='transparent'),
          axis.line = element_line(color = "black"),            
          legend.text =element_text(size=15),                  
          title = element_text(size = 18),
          panel.grid = element_blank()
        )+
        labs(x = "Stars", y = "Count")
      ch22 <- ggplot(oout, aes(review_count)) +
        geom_histogram(bins = 20,color='darkblue',fill='lightblue')+
        theme_bw()+
        theme(
          axis.text = element_text(face="plain",size=15),     
          axis.title = element_text(face = "plain",size=15),    
          legend.title = element_blank(),                      
          panel.border=element_rect(fill='transparent',         
                                    color='transparent'),
          axis.line = element_line(color = "black"),           
          legend.text =element_text(size=15),                   
          panel.grid = element_blank()#去除背景的分割线
        )+
        labs(x = "Number of Reviews", y = "Count")
      multiplot(ch21,ch22, cols=2)
      
    }
    
    else{
      fff <- bus[(bus$state == input$state) & (bus$city == input$city),]$business_id
      oout <- bus[bus$business_id %in% fff, ]
      ch31 <- ggplot(oout, aes(stars)) +
        geom_histogram(bins = 10,color='darkblue',fill='lightblue')+
        theme_bw()+
        theme(
          axis.text = element_text(face="plain",size=15),      
          axis.title = element_text(face = "plain",size=15),     
          legend.title = element_blank(),                     
          panel.border=element_rect(fill='transparent',color='transparent'),
          axis.line = element_line(color = "black"),            
          legend.text =element_text(size=15),                  
          title = element_text(size = 18),
          panel.grid = element_blank()
        )+
        geom_vline(xintercept = bus$stars[(bus$state == input$state) & (bus$city == input$city) & (bus$name==input$name)],color="red")+
        labs(x = "Stars", y = "Count")
      ch32 <- ggplot(oout, aes(review_count)) +
        geom_histogram(bins = 20,color='darkblue',fill='lightblue')+
        theme_bw()+
        theme(
          axis.text = element_text(face="plain",size=15),     
          axis.title = element_text(face = "plain",size=15),    
          legend.title = element_blank(),                      
          panel.border=element_rect(fill='transparent',         
                                    color='transparent'),
          axis.line = element_line(color = "black"),           
          legend.text =element_text(size=15),                   
          panel.grid = element_blank()#去除背景的分割线
        )+
        geom_vline(xintercept = bus$review_count[(bus$state == input$state) & (bus$city == input$city) & (bus$name==input$name)],color="red")+
        labs(x = "Number of Reviews", y = "Count")
      multiplot(ch31,ch32, cols=2)
      
    }
    
    ch1 <- ggplot(oout, aes(stars)) +
      geom_histogram(bins = 10,color='darkblue',fill='lightblue')+
      theme_bw()+
      theme(
        axis.text = element_text(face="plain",size=15),      
        axis.title = element_text(face = "plain",size=15),     
        legend.title = element_blank(),                     
        panel.border=element_rect(fill='transparent',color='transparent'),
        axis.line = element_line(color = "black"),            
        legend.text =element_text(size=15),                  
        title = element_text(size = 18),
        panel.grid = element_blank()
      )+
      geom_vline(xintercept = bus$stars[(bus$state == input$state) & (bus$city == input$city) & (bus$name==input$name)],color="red")+
      labs(x = "Stars", y = "Count")
    ch2 <- ggplot(oout, aes(review_count)) +
      geom_histogram(bins = 20,color='darkblue',fill='lightblue')+
      theme_bw()+
      theme(
        axis.text = element_text(face="plain",size=15),     
        axis.title = element_text(face = "plain",size=15),    
        legend.title = element_blank(),                      
        panel.border=element_rect(fill='transparent',         
                                  color='transparent'),
        axis.line = element_line(color = "black"),           
        legend.text =element_text(size=15),                   
        panel.grid = element_blank()#去除背景的分割线
      )+
      geom_vline(xintercept = bus$review_count[(bus$state == input$state) & (bus$city == input$city) & (bus$name==input$name)],color="red")+
      labs(x = "Number of Reviews", y = "Count")
    multiplot(ch1,ch2, cols=2)
  })
  
  output$beats <- renderText({
    if (input$state=='All'){
      paste("The distribution of stars of all steakhouses in four states is shown in the left figure.")
    }
    else if (input$state != 'All' & input$city == 'All'){
      paste("The distribution of stars of all steakhouses in the selected state is shown in the left figure.")
    }
    else if (input$state != 'All' & input$city != 'All' & input$name == 'All') {
      paste("The distribution of stars of all steakhouses in the selected city is shown in the left figure.")
    }
    else {
      selected <- bus$stars[bus$name == input$name & bus$state == input$state & bus$city == input$city]
      p_all <- 100*round(sum(bus$stars<selected)/length(bus$stars),3)
      sc <- bus$business_id[bus$state==input$state & bus$city==input$city]
      city <- bus$stars[bus$business_id %in% sc]
      p_city <- 100*round(sum(city<selected)/length(city),3)
      st <- bus$business_id[bus$state==input$state]
      state <- bus$stars[bus$business_id %in% st]
      p_state <- 100*round(sum(state<selected)/length(state),3)
      paste("The distribution of stars of all steakhouses in the selected city is shown in the left figure. Your steakhouse is a",bus$stars[bus$name==input$name & bus$state==input$state & bus$city==input$city],"star restaurant.","You have beaten",p_city,"% steakhouses in the city,",p_state,"% steakhouses in the states, and",p_all,"% steakhouses in all four states.","\n","You may have a look at the distribution of the stars by reselecting in the sidebar.",sep=" ")
    }
  })
  
  output$pop <- renderText({
    if (input$state=='All'){
      paste("The distribution of the number of reviews of all steakhouses in four states is shown in the right figure.")
    }
    else if (input$state != 'All' & input$city == 'All'){
      paste("The distribution of the number of reviews of all steakhouses in the selected state is shown in the right figure.")
    }
    else if (input$state != 'All' & input$city != 'All' & input$name == 'All') {
      paste("The distribution of the number of reviews of all steakhouses in the selected city is shown in the right figure.")
    }
    else {
      selected1 <- bus$review_count[bus$name == input$name & bus$state == input$state & bus$city == input$city]
      p_all1 <- 100*round(sum(bus$review_count<selected1)/length(bus$review_count),3)
      sc1 <- bus$business_id[bus$state==input$state & bus$city==input$city]
      city1 <- bus$review_count[bus$business_id %in% sc1]
      p_city1 <- 100*round(sum(city1<selected1)/length(city1),3)
      st1 <- bus$business_id[bus$state==input$state]
      state1 <- bus$review_count[bus$business_id %in% st1]
      p_state1 <- 100*round(sum(state1<selected1)/length(state1),3)
      paste("The distribution of review_counts of all steakhouses in the selected city is shown in the right figure. Your steakhouse has ",bus$review_count[bus$name==input$name & bus$city==input$city & bus$state==input$state],"reviews in total.","You have beaten",p_city1,"% steakhouses in the city,",p_state1,"% steakhouses in the states, and",p_all1,"% steakhouses in all four states.","\n","You may have a look at the distribution of the stars by reselecting in the sidebar.",sep=" ")
    }
  })
  
  output$try <- renderText({
    paste("This app is designed to provide valuable information and actionable advice about the steakhouses in OH, PA, WI, and IL. The main functions are as follow:")
  })
  
  output$food <- renderImage({
    filename <- normalizePath(file.path('./food.jpg'))
    list(src = filename,         
         width = 500,
         height = 400)
  }, deleteFile = FALSE)
  
  output$service <- renderImage({
    filename <- normalizePath(file.path('./service.jpg'))
    list(src = filename,         
         width = 500,
         height = 400)
  }, deleteFile = FALSE)
  
  
  output$suggest <- renderText({
    id0 <- bus$business_id[bus$state==input$state & bus$city == input$city & bus$name == input$name]
    if (input$name=='All'){
      "Please select your steakhouse first."
    }
    else{
      if (id0 %in% bus$business_id){
        as.character(suggestions[suggestions$business_id==id0, 'suggestion'])
      }
      else{
        "Missing too many attributes to give suggestions!"
      }
    }
  })
  
  output$tt <- renderTable({
    id1 <- bus$business_id[bus$state==input$state & bus$city == input$city & bus$name == input$name]
    if (input$name=='All'){
      ooout <- as.data.frame("Please select your steakhouse first.")
    }
    else{
      if (id1 %in% bus$business_id){
        ooout <- as.data.frame(strsplit(suggestions[suggestions$business_id==id1, 'suggestion'], "\n")[[1]])
      }
      else{
        ooout <- as.data.frame("Missing too many attributes to give suggestions!")
      }
    }
    colnames(ooout) <- 'Suggestions:'
    ooout
  })
  
  
})    



# Run the application 
shinyApp(ui = ui, server = server)


